import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import NavBar1 from "../components/NavBar1";
import Statusbar1 from "../components/Statusbar1";
import Dropdown from "../components/Dropdown";

const Withdrawal: FunctionComponent = () => {
  const navigate = useNavigate();

  const onLineFrameContainerClick = useCallback(() => {
    navigate("/portfolio");
  }, [navigate]);

  const onFrameContainerClick = useCallback(() => {
    navigate("/payment");
  }, [navigate]);

  const onTextContainer1Click = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  const onWithdrawalButtonClick = useCallback(() => {
    navigate("/payment");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-0 overflow-hidden flex flex-row items-start justify-start gap-[0px_62px] tracking-[normal] mq450:gap-[0px_62px] mq800:gap-[0px_62px] mq1300:flex-wrap">
      <NavBar1
        onAgencyLabelNodeClick={onLineFrameContainerClick}
        onFrameContainerClick={onFrameContainerClick}
        onSALText1Click={onTextContainer1Click}
      />
      <main className="mb-0 h-[1017px] w-[1076px] relative max-w-full text-left text-lg text-black font-body-m mq450:h-auto mq450:min-h-[1017]">
        <Statusbar1 logo1="/logo-13@2x.png" todayTop="-7px" />
        <div className="absolute top-[16px] left-[0px] bg-gray-0 w-full flex flex-row items-center justify-between gap-[20px] max-w-full z-[2] text-cornflowerblue-200 mq450:flex-wrap">
          <div className="relative leading-[32px] font-medium">
            Welcome back!
          </div>
          <div className="flex flex-row items-center justify-start gap-[0px_5px] text-sm">
            <div className="relative leading-[20px]">Harvey Specter</div>
            <img
              className="h-6 w-6 relative rounded-81xl overflow-hidden shrink-0"
              loading="lazy"
              alt=""
              src="/frame-63.svg"
            />
          </div>
        </div>
        <h1 className="m-0 absolute top-[287px] left-[247px] text-17xl leading-[140%] font-medium font-inherit mq450:text-3xl mq450:leading-[30px] mq800:text-10xl mq800:leading-[40px]">
          Withdrawal
        </h1>
        <div className="absolute top-[471px] left-[142px] w-[420px] flex flex-col items-start justify-start gap-[20px_0px] max-w-full text-xl">
          <div className="self-stretch flex flex-row items-start justify-between py-0 pr-px pl-0 gap-[20px] mq450:flex-wrap">
            <div className="relative leading-[140%] font-medium mq450:text-base mq450:leading-[22px]">
              Account Total :
            </div>
            <div className="relative text-5xl leading-[140%] mq450:text-lgi mq450:leading-[27px]">
              Ksh. 38400
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[5.55px_0px] max-w-full text-base-6 text-grey-700">
            <div className="flex flex-row items-center justify-start py-0 pr-5 pl-0 gap-[0px_5.55px]">
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                alt=""
                src="/plus.svg"
              />
              <div className="relative leading-[140%] whitespace-pre-wrap">{`Withdrawal Amount:  `}</div>
            </div>
            <div className="self-stretch h-[58.3px] rounded-[5.55px] box-border overflow-hidden shrink-0 flex flex-row items-center justify-start py-[16.646615982055664px] pr-[13px] pl-[12.484962463378906px] gap-[0px_273.28px] max-w-full border-[1.4px] border-solid border-grey-500">
              <input
                className="w-full [border:none] [outline:none] bg-[transparent] h-[27px] flex-1 flex flex-row items-center justify-start font-body-m text-lgi-4 text-gray1-400 min-w-[237px] max-w-full"
                placeholder="48,000"
                type="text"
              />
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                alt=""
                src="/windowclose.svg"
              />
            </div>
            <div className="w-[86px] h-[22px] hidden flex-row items-center justify-start gap-[0px_5.55px] text-black">
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden min-h-[22px]"
                alt=""
                src="/plus.svg"
              />
              <div className="h-[23px] relative leading-[140%] font-black inline-block whitespace-nowrap shrink-0">
                Helper text
              </div>
            </div>
          </div>
        </div>
        <button
          className="cursor-pointer [border:none] p-[21px] bg-primary-600 absolute top-[651.8px] left-[142px] rounded-4xs w-[420px] overflow-hidden flex flex-row items-center justify-center box-border max-w-full hover:bg-cornflowerblue-100"
          onClick={onWithdrawalButtonClick}
        >
          <div className="relative text-xl leading-[140%] font-extrabold font-body-m text-gray-0 text-left mq450:text-base mq450:leading-[22px]">
            Submit
          </div>
        </button>
        <Dropdown tDX="Withdrawal" propTop="377px" propLeft="142px" />
      </main>
    </div>
  );
};

export default Withdrawal;
