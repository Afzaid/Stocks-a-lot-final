import { FunctionComponent } from "react";
import NavBar3 from "../components/NavBar3";
import Statusbar2 from "../components/Statusbar2";
import TransactionHistory1 from "../components/TransactionHistory1";

const TransactionHistory: FunctionComponent = () => {
  return (
    <div className="w-full relative bg-gray-0 overflow-hidden flex flex-row items-start justify-start gap-[0px_62px] tracking-[normal] mq450:gap-[0px_62px] mq800:gap-[0px_62px] mq1300:flex-wrap">
      <NavBar3 />
      <main className="mt-[-40px] h-[1024px] w-[1076px] relative max-w-full text-left text-sm text-cornflowerblue-200 font-body-m mq450:h-auto mq450:min-h-[1024]">
        <Statusbar2 />
        <div className="absolute top-[70px] left-[0px] bg-gray-0 w-full flex flex-row items-center justify-between gap-[20px] max-w-full z-[2] text-lg mq450:flex-wrap">
          <div className="relative leading-[32px] font-medium">
            Welcome back!
          </div>
          <div className="flex flex-row items-center justify-start gap-[0px_5px] text-sm">
            <div className="relative leading-[20px]">Harvey Specter</div>
            <img
              className="h-6 w-6 relative rounded-81xl overflow-hidden shrink-0"
              loading="lazy"
              alt=""
              src="/frame-63.svg"
            />
          </div>
        </div>
        <TransactionHistory1 />
        <nav className="m-0 absolute top-[168px] left-[0px] w-[734px] flex flex-row items-start justify-start py-0 pr-px pl-0 box-border gap-[0px_8px] max-w-full whitespace-nowrap text-left text-xs-7 text-text-color-80-opacity font-outfit mq800:flex-wrap">
          <div className="flex-1 rounded-[3.64px] bg-honeydew box-border overflow-hidden flex flex-col items-start justify-start pt-[11px] px-[11px] pb-[13px] gap-[3px_0px] min-w-[179px] border-[0.7px] border-solid border-secondary-background">
            <div className="w-[90px] relative tracking-[0.01em] inline-block box-border pr-5">
              Stocks Worth
            </div>
            <div className="w-[83px] relative text-base font-medium text-seagreen inline-block whitespace-nowrap box-border pr-5">
              ₹430.00
            </div>
            <div className="w-[102px] relative text-5xs-3 tracking-[0.01em] text-inactive-state-color inline-block box-border pr-5">
              as of 01-December 2022
            </div>
          </div>
          <div className="flex-1 rounded-[3.64px] bg-grey-500 box-border overflow-hidden flex flex-col items-start justify-start pt-[11px] px-3 pb-[13px] gap-[3px_0px] min-w-[179px] border-[0.7px] border-solid border-secondary-background">
            <div className="w-[67px] relative tracking-[0.01em] inline-block box-border pr-5">
              Deposits
            </div>
            <div className="w-[83px] relative text-base font-medium text-seagreen inline-block whitespace-nowrap box-border pr-5">
              ₹430.00
            </div>
            <div className="w-[102px] relative text-5xs-3 tracking-[0.01em] text-inactive-state-color inline-block box-border pr-5">
              as of 01-December 2022
            </div>
          </div>
          <div className="flex-1 rounded-[3.64px] bg-gray-0 box-border overflow-hidden flex flex-col items-start justify-start pt-[11px] px-3 pb-[13px] gap-[3px_0px] min-w-[179px] border-[0.7px] border-solid border-secondary-background">
            <div className="w-[88px] relative tracking-[0.01em] inline-block box-border pr-5">
              Withdrawals
            </div>
            <div className="w-[83px] relative text-base font-medium text-seagreen inline-block whitespace-nowrap box-border pr-5">
              ₹430.00
            </div>
            <div className="w-[102px] relative text-5xs-3 tracking-[0.01em] text-inactive-state-color inline-block box-border pr-5">
              as of 01-December 2022
            </div>
          </div>
        </nav>
        <button className="cursor-pointer [border:none] p-[11px] bg-primary-600 absolute top-[896px] left-[454px] rounded-4xs w-[266px] overflow-hidden flex flex-row items-center justify-center box-border whitespace-nowrap hover:bg-cornflowerblue-100">
          <div className="w-[222px] relative text-sm leading-[140%] font-extrabold font-body-m text-gray-0 text-left flex items-center box-border pl-5 pr-5">
            Print Transaction History
          </div>
        </button>
        <div className="absolute top-[294px] left-[0px] w-[220px] flex flex-col items-start justify-start gap-[8px_0px] text-gray-900">
          <div className="self-stretch rounded-3xs bg-gray-50 flex flex-row items-center justify-center p-3">
            <div className="flex-1 flex flex-row items-center justify-between py-0 px-1 gap-[20px]">
              <div className="relative leading-[20px]">TDX</div>
              <img
                className="h-6 w-6 relative"
                alt=""
                src="/vuesaxlineararrowdown.svg"
              />
            </div>
          </div>
          <div className="self-stretch h-2 rounded-3xs bg-gray-50 box-border flex flex-col items-center justify-start pt-1 px-[3px] pb-[3px] opacity-[0] text-base border-[1px] border-solid border-gray-4">
            <div className="self-stretch h-0 flex flex-col items-start justify-start py-0 px-3 box-border gap-[12px_0px]">
              <div className="h-6 relative tracking-[0.15px] leading-[24px] font-black inline-block box-border pr-5">
                Options 1
              </div>
              <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-gray-4" />
            </div>
            <div className="self-stretch h-0 flex flex-col items-start justify-start py-0 px-3 box-border gap-[12px_0px]">
              <div className="h-6 relative tracking-[0.15px] leading-[24px] font-black inline-block box-border pr-5">
                Options 2
              </div>
              <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-gray-4" />
            </div>
            <div className="self-stretch h-px flex flex-col items-start justify-start pt-3 px-3 pb-0 box-border gap-[12px_0px]">
              <div className="h-6 relative tracking-[0.15px] leading-[24px] font-black inline-block box-border pr-5">
                Options 3
              </div>
              <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-gray-4" />
            </div>
            <div className="self-stretch h-0 flex flex-col items-start justify-start py-0 px-3 box-border gap-[12px_0px]">
              <div className="h-6 relative tracking-[0.15px] leading-[24px] font-black inline-block box-border pr-5">
                Options 4
              </div>
              <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-gray-4" />
            </div>
            <div className="self-stretch flex-1 flex flex-row items-start justify-start py-0 px-3">
              <div className="h-0 w-[101px] flex flex-col items-start justify-start pt-3 pb-0 pr-5 pl-0 box-border relative gap-[12px_0px]">
                <div className="h-6 absolute !m-[0] left-[0px] tracking-[0.15px] leading-[24px] font-black inline-block">
                  Options 5
                </div>
                <div className="w-[188px] h-px relative box-border hidden z-[1] border-t-[1px] border-solid border-gray-4" />
              </div>
            </div>
          </div>
        </div>
        <div className="absolute top-[263px] left-[8px] leading-[20px] text-black inline-block w-[92px] h-[17px]">
          Stock Ticker
        </div>
      </main>
    </div>
  );
};

export default TransactionHistory;
