import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import NavBar2 from "../components/NavBar2";
import Dropdown1 from "../components/Dropdown1";
import AMZN from "../components/AMZN";

const Buy: FunctionComponent = () => {
  const navigate = useNavigate();

  const onArrowInstanceContainerClick = useCallback(() => {
    navigate("/portfolio");
  }, [navigate]);

  const onPaymentinputContainerClick = useCallback(() => {
    navigate("/payment");
  }, [navigate]);

  const onFrameContainer1Click = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  const onFrameButtonClick = useCallback(() => {
    navigate("/portfolio");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-0 overflow-hidden flex flex-row items-start justify-start gap-[0px_62px] tracking-[normal] mq450:gap-[0px_62px] mq800:gap-[0px_62px] mq1300:flex-wrap">
      <NavBar2
        onProfileINSTANCEClick={onArrowInstanceContainerClick}
        onTextContainerClick={onPaymentinputContainerClick}
        onMessagesettingContainer1Click={onFrameContainer1Click}
      />
      <main className="w-[1076px] flex flex-col items-start justify-start pt-[30px] px-0 pb-0 box-border max-w-full">
        <section className="self-stretch flex flex-col items-end justify-start gap-[84px_0px] max-w-full text-left text-17xl text-black font-body-m mq800:gap-[84px_0px] mq1125:gap-[84px_0px]">
          <header className="self-stretch bg-gray-0 flex flex-row items-center justify-between top-[0] z-[99] sticky gap-[20px] text-left text-lg text-cornflowerblue-200 font-body-m">
            <div className="relative leading-[32px] font-medium whitespace-nowrap">
              Welcome back!
            </div>
            <div className="flex flex-row items-center justify-start gap-[0px_5px] text-sm">
              <div className="relative leading-[20px] whitespace-nowrap">
                Harvey Specter
              </div>
              <img
                className="h-6 w-6 relative rounded-81xl overflow-hidden shrink-0"
                loading="lazy"
                alt=""
                src="/frame-63.svg"
              />
            </div>
          </header>
          <div className="w-[992px] flex flex-row items-start justify-start py-0 px-[58px] box-border max-w-full mq1125:pl-[29px] mq1125:pr-[29px] mq1125:box-border">
            <div className="flex-1 flex flex-col items-center justify-start gap-[50px_0px] max-w-full mq450:gap-[50px_0px]">
              <h1 className="m-0 relative text-inherit leading-[140%] font-medium font-inherit mq450:text-3xl mq450:leading-[30px] mq800:text-10xl mq800:leading-[40px]">
                Buy
              </h1>
              <div className="self-stretch flex flex-row items-center justify-start gap-[0px_36px] max-w-full mq450:gap-[0px_36px] mq800:flex-wrap">
                <form className="m-0 flex-1 flex flex-col items-start justify-start gap-[40px_0px] min-w-[273px] max-w-full mq450:gap-[40px_0px]">
                  <div className="self-stretch flex flex-col items-start justify-start gap-[14px_0px] max-w-full">
                    <Dropdown1
                      propHeight="unset"
                      propDisplay="inline-block"
                      propPaddingRight="unset"
                      propHeight1="unset"
                      propDisplay1="inline-block"
                      propPaddingRight1="unset"
                      propPaddingRight2="unset"
                      propHeight2="unset"
                      propDisplay2="inline-block"
                      propPaddingRight3="unset"
                      propWidth="81px"
                    />
                    <div className="self-stretch flex flex-col items-start justify-start gap-[20px_0px] max-w-full">
                      <div className="self-stretch flex flex-row items-start justify-between py-0 pr-px pl-0 gap-[20px] mq450:flex-wrap">
                        <div className="relative text-xl leading-[140%] font-medium font-body-m text-black text-left mq450:text-base mq450:leading-[22px]">
                          Account Total :
                        </div>
                        <div className="relative text-5xl leading-[140%] font-body-m text-black text-left mq450:text-lgi mq450:leading-[27px]">
                          Ksh. 38400
                        </div>
                      </div>
                      <div className="self-stretch flex flex-col items-start justify-start gap-[5.55px_0px] max-w-full">
                        <div className="flex flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="relative text-base-6 leading-[140%] font-body-m text-grey-700 text-left">
                            Abbreviation:
                          </div>
                        </div>
                        <div className="self-stretch h-[58.3px] rounded-[5.55px] box-border overflow-hidden shrink-0 flex flex-row items-center justify-start py-[16.646615982055664px] pr-[13px] pl-[12.484962463378906px] gap-[0px_273.28px] max-w-full border-[1.4px] border-solid border-grey-500 mq450:gap-[0px_273.28px]">
                          <input
                            className="w-full [border:none] [outline:none] bg-[transparent] h-[27px] flex-1 flex flex-row items-center justify-start font-body-m text-lgi-4 text-gray1-400 min-w-[237px] max-w-full"
                            placeholder="AAPL"
                            type="text"
                          />
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/windowclose.svg"
                          />
                        </div>
                        <div className="w-[86px] h-[22px] hidden flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden min-h-[22px]"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="h-[23px] relative text-base-6 leading-[140%] font-black font-body-m text-black text-left inline-block whitespace-nowrap shrink-0">
                            Helper text
                          </div>
                        </div>
                      </div>
                      <div className="self-stretch flex flex-col items-start justify-start gap-[5.55px_0px] max-w-full">
                        <div className="flex flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="w-[126px] relative text-base-6 leading-[140%] font-body-m text-grey-700 whitespace-pre-wrap text-left flex items-center">{`Share Amount:  `}</div>
                        </div>
                        <div className="self-stretch h-[58.3px] rounded-[5.55px] box-border overflow-hidden shrink-0 flex flex-row items-center justify-start py-[16.646615982055664px] pr-[13px] pl-[12.484962463378906px] gap-[0px_273.28px] max-w-full border-[1.4px] border-solid border-grey-500 mq450:gap-[0px_273.28px]">
                          <input
                            className="w-full [border:none] [outline:none] bg-[transparent] h-[27px] flex-1 flex flex-row items-center justify-start font-body-m text-lgi-4 text-gray1-400 min-w-[237px] max-w-full"
                            placeholder="48,000"
                            type="text"
                          />
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/windowclose.svg"
                          />
                        </div>
                        <div className="w-[86px] h-[22px] hidden flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden min-h-[22px]"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="h-[23px] relative text-base-6 leading-[140%] font-black font-body-m text-black text-left inline-block whitespace-nowrap shrink-0">
                            Helper text
                          </div>
                        </div>
                      </div>
                      <div className="self-stretch flex flex-col items-start justify-start gap-[5.55px_0px] max-w-full">
                        <div className="flex flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="relative text-base-6 leading-[140%] font-body-m text-grey-700 text-left">
                            Purchase Total:
                          </div>
                        </div>
                        <div className="self-stretch h-[58.3px] rounded-[5.55px] box-border overflow-hidden shrink-0 flex flex-row items-center justify-start py-[16.646615982055664px] pr-[13px] pl-[12.484962463378906px] gap-[0px_273.28px] max-w-full border-[1.4px] border-solid border-grey-500 mq450:gap-[0px_273.28px]">
                          <input
                            className="w-full [border:none] [outline:none] bg-[transparent] h-[27px] flex-1 flex flex-row items-center justify-start font-body-m text-lgi-4 text-gray1-400 min-w-[237px] max-w-full"
                            placeholder="48,000"
                            type="text"
                          />
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                            alt=""
                            src="/windowclose.svg"
                          />
                        </div>
                        <div className="w-[86px] h-[22px] hidden flex-row items-center justify-start gap-[0px_5.55px]">
                          <img
                            className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden min-h-[22px]"
                            alt=""
                            src="/plus.svg"
                          />
                          <div className="h-[23px] relative text-base-6 leading-[140%] font-black font-body-m text-black text-left inline-block whitespace-nowrap shrink-0">
                            Helper text
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <button
                    className="cursor-pointer [border:none] p-[21px] bg-primary-600 self-stretch rounded-4xs overflow-hidden flex flex-row items-center justify-center hover:bg-cornflowerblue-100"
                    onClick={onFrameButtonClick}
                  >
                    <div className="relative text-xl leading-[140%] font-extrabold font-body-m text-gray-0 text-left mq450:text-base mq450:leading-[22px]">
                      Submit
                    </div>
                  </button>
                </form>
                <AMZN />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Buy;
