import { FunctionComponent } from "react";
import FrameComponent from "../components/FrameComponent";

const SignIn: FunctionComponent = () => {
  return (
    <div className="w-full h-[1024px] relative bg-whitesmoke-100 overflow-hidden flex flex-row items-start justify-center pt-[260px] pb-[422px] pr-[22px] pl-5 box-border tracking-[normal] mq450:h-auto">
      <FrameComponent />
    </div>
  );
};

export default SignIn;
