import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";

const Home: FunctionComponent = () => {
  const navigate = useNavigate();

  const onLogInRegisterFrameClick = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  const onLogInRegisterFrame1Click = useCallback(() => {
    navigate("/register");
  }, [navigate]);

  return (
    <div className="w-full relative bg-whitesmoke-100 overflow-hidden flex flex-row items-center justify-center pt-[211px] pb-[210px] pr-[21px] pl-5 box-border tracking-[normal] text-left text-13xl text-primary-800 font-heading-6">
      <div className="w-[719px] rounded-xl bg-gray-0 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] flex flex-col items-center justify-start pt-[60px] px-[54px] pb-[54px] box-border gap-[142px_0px] max-w-full mq450:gap-[142px_0px] mq675:pt-[39px] mq675:pb-[35px] mq675:box-border mq750:gap-[142px_0px] mq750:pl-[27px] mq750:pr-[27px] mq750:box-border">
        <div className="w-80 flex flex-row items-start justify-start py-0 pr-0 pl-[3px] box-border">
          <div className="flex-1 flex flex-col items-center justify-start gap-[50px_0px] mq450:gap-[50px_0px]">
            <div className="self-stretch flex flex-col items-center justify-start gap-[37px_0px] mq450:gap-[37px_0px]">
              <div className="self-stretch flex flex-row flex-wrap items-center justify-start gap-[0px_29px]">
                <img
                  className="h-[90px] w-[86.1px] relative"
                  loading="lazy"
                  alt=""
                  src="/group-39796.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start pt-0.5 px-0 pb-0 box-border min-w-[131px]">
                  <h2 className="m-0 relative text-inherit leading-[64px] font-bold font-inherit mq450:text-lgi mq450:leading-[38px] mq750:text-7xl mq750:leading-[51px]">
                    Stocks A Lot
                  </h2>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-2.5 pl-0 text-17xl text-black font-body-m">
                <h2 className="m-0 relative text-inherit leading-[64px] font-extrabold font-inherit mq450:text-3xl mq450:leading-[38px] mq750:text-10xl mq750:leading-[51px]">
                  SAL
                </h2>
              </div>
            </div>
            <div className="flex flex-row items-start justify-start py-0 pr-[3px] pl-0 text-xl text-black font-body-m">
              <div className="relative leading-[64px] mq450:text-base mq450:leading-[51px]">
                Welcome Message
              </div>
            </div>
          </div>
        </div>
        <div className="self-stretch flex flex-row items-start justify-start py-0 px-[21px] gap-[0px_37px] top-[0] z-[99] sticky mq675:gap-[0px_37px]">
          <button
            className="cursor-pointer [border:none] py-[11px] pr-[121px] pl-[103px] bg-primary-600 rounded-4xs overflow-hidden flex flex-row items-center justify-center whitespace-nowrap hover:bg-cornflowerblue-100 mq450:pl-5 mq450:pr-5 mq450:box-border"
            onClick={onLogInRegisterFrameClick}
          >
            <div className="relative text-sm leading-[140%] font-extrabold font-body-m text-gray-0 text-left">
              Log In
            </div>
          </button>
          <button
            className="cursor-pointer [border:none] py-[11px] pr-5 pl-[21px] bg-primary-600 flex-1 rounded-4xs overflow-hidden flex flex-row items-center justify-center hover:bg-cornflowerblue-100"
            onClick={onLogInRegisterFrame1Click}
          >
            <div className="relative text-sm leading-[140%] font-extrabold font-body-m text-gray-0 text-left">
              Register
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Home;
