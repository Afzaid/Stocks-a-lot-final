import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Dropdown from "../components/Dropdown";

const Deposit: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    navigate("/portfolio");
  }, [navigate]);

  const onDateAndTimeClick = useCallback(() => {
    navigate("/payment");
  }, [navigate]);

  const onDepositSectionContainerClick = useCallback(() => {
    navigate("/transaction-history");
  }, [navigate]);

  const onFrameContainer1Click = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  const onDepositFieldClick = useCallback(() => {
    navigate("/payment");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-0 overflow-hidden flex flex-row items-start justify-start gap-[0px_62px] tracking-[normal] mq450:gap-[0px_62px] mq800:gap-[0px_62px] mq1300:flex-wrap">
      <nav className="m-0 bg-gray-0 overflow-hidden flex flex-col items-start justify-start py-10 px-0 gap-[80px_0px] text-left text-base text-gray-400 font-body-m mq450:pt-5 mq450:pb-5 mq450:box-border mq1125:pt-[26px] mq1125:pb-[26px] mq1125:box-border">
        <div className="flex flex-row items-start justify-start py-0 pr-0 pl-8 text-5xl text-primary-800 font-heading-6">
          <div className="flex flex-row items-center justify-start gap-[14px]">
            <img
              className="h-[45px] w-[43.1px] relative"
              loading="lazy"
              alt=""
              src="/group-397961.svg"
            />
            <h3 className="m-0 relative text-inherit leading-[32px] font-bold font-inherit mq450:text-lgi mq450:leading-[26px]">
              Stocks A Lot
            </h3>
          </div>
        </div>
        <div className="w-[196px] flex flex-col items-center justify-start pt-0 pb-[243px] pr-5 pl-0 box-border gap-[40px_0px] mq800:pb-[158px] mq800:box-border">
          <div className="flex flex-row items-start justify-start py-0 pr-3.5 pl-8">
            <div className="flex flex-row items-start justify-start gap-[0px_16px]">
              <img
                className="h-6 w-6 relative min-h-[24px]"
                loading="lazy"
                alt=""
                src="/setting.svg"
              />
              <div className="relative leading-[24px]">Dashboard</div>
            </div>
          </div>
          <div className="flex flex-row items-start justify-start py-0 pr-[23px] pl-5">
            <div className="flex flex-row items-start justify-start gap-[0px_16px]">
              <img
                className="h-6 w-6 relative min-h-[24px]"
                loading="lazy"
                alt=""
                src="/essentional.svg"
              />
              <div className="relative leading-[24px]">Discover</div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-center justify-start gap-[31px_0px]">
            <div className="flex flex-row items-start justify-start py-0 pr-5 pl-6">
              <div
                className="flex flex-row items-start justify-start gap-[0px_16px] cursor-pointer"
                onClick={onFrameContainerClick}
              >
                <img
                  className="h-6 w-6 relative min-h-[24px]"
                  loading="lazy"
                  alt=""
                  src="/school1.svg"
                />
                <div className="relative leading-[24px]">Portofolio</div>
              </div>
            </div>
            <div className="self-stretch flex flex-col items-center justify-start gap-[40px_0px]">
              <div className="self-stretch flex flex-col items-end justify-start gap-[25px_0px] text-primary-600">
                <div className="flex flex-row items-start justify-start py-0 pr-[30px] pl-0">
                  <div className="flex flex-row items-center justify-start gap-[0px_26px]">
                    <div className="h-12 w-1.5 relative rounded-tl-none rounded-tr rounded-br rounded-bl-none bg-primary-600" />
                    <div className="flex flex-col items-start justify-start pt-0 px-0 pb-1.5">
                      <div
                        className="flex flex-row items-start justify-start gap-[0px_16px] cursor-pointer"
                        onClick={onDateAndTimeClick}
                      >
                        <img
                          className="h-6 w-6 relative min-h-[24px]"
                          loading="lazy"
                          alt=""
                          src="/money1.svg"
                        />
                        <div className="relative leading-[24px] font-semibold">
                          Payment
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  className="flex flex-row items-start justify-start py-0 pr-0 pl-5 gap-[0px_16px] cursor-pointer text-gray-400"
                  onClick={onDepositSectionContainerClick}
                >
                  <img
                    className="h-6 w-6 relative min-h-[24px]"
                    loading="lazy"
                    alt=""
                    src="/arrow.svg"
                  />
                  <div className="relative leading-[24px]">Transactions</div>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-[49px] pl-5">
                <div className="flex flex-row items-start justify-start gap-[0px_16px]">
                  <img
                    className="h-6 w-6 relative min-h-[24px]"
                    loading="lazy"
                    alt=""
                    src="/message.svg"
                  />
                  <div className="relative leading-[24px]">Inbox</div>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-[27px] pl-5">
                <div className="flex flex-row items-start justify-start gap-[0px_16px]">
                  <img
                    className="h-6 w-6 relative min-h-[24px]"
                    loading="lazy"
                    alt=""
                    src="/setting-1.svg"
                  />
                  <div className="relative leading-[24px]">Settings</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-row items-start justify-start py-0 px-8">
          <div className="flex flex-col items-start justify-start gap-[40px_0px]">
            <div className="flex flex-row items-start justify-start gap-[0px_16px]">
              <img
                className="h-6 w-6 relative min-h-[24px]"
                loading="lazy"
                alt=""
                src="/user.svg"
              />
              <div className="relative leading-[24px]">Profile</div>
            </div>
            <div
              className="flex flex-row items-start justify-start gap-[0px_16px] cursor-pointer"
              onClick={onFrameContainer1Click}
            >
              <img
                className="h-6 w-6 relative min-h-[24px]"
                loading="lazy"
                alt=""
                src="/arrow-1.svg"
              />
              <div className="relative leading-[24px]">Logout</div>
            </div>
          </div>
        </div>
      </nav>
      <main className="h-[1024px] w-[1076px] relative max-w-full text-left text-lg text-black font-body-m mq450:h-auto mq450:min-h-[1024]">
        <div className="absolute top-[0px] left-[721px] w-[355px] flex flex-col items-center justify-start pt-[114px] px-0 pb-[31px] box-border gap-[28px_0px] max-w-full text-dark-quiz">
          <div className="w-full h-full absolute !m-[0] top-[0px] right-[0px] bottom-[0px] bg-gray-0 shadow-[-24px_0px_80px_rgba(49,_79,_124,_0.02)]" />
          <div className="w-[327px] h-[285px] flex flex-col items-start justify-start py-0 px-5 box-border gap-[17px] max-w-full z-[1]">
            <div className="self-stretch flex flex-row items-center justify-between gap-[20px]">
              <div className="flex flex-col items-start justify-start pt-0 px-0 pb-0.5">
                <div className="relative leading-[24px] font-medium">
                  My Balances
                </div>
              </div>
              <div className="h-[38.1px] w-[37.5px] relative flex items-center justify-center">
                <img
                  className="h-full w-full object-contain absolute left-[0px] top-[19px] [transform:scale(3.133)]"
                  loading="lazy"
                  alt=""
                  src="/add-card2.svg"
                />
              </div>
            </div>
            <div className="self-stretch flex-1 flex flex-col items-start justify-start gap-[21px_0px] text-gray-0">
              <div className="self-stretch flex-1 flex flex-row items-start justify-start gap-[0px_13px]">
                <div className="flex-[0.8413] flex flex-col items-start justify-start py-[13px] pr-[30px] pl-3 relative gap-[29px]">
                  <div className="w-full h-full absolute !m-[0] top-[-0.2px] right-[0.8px] bottom-[0.2px] left-[-0.4px]">
                    <div className="absolute h-full w-full top-[0.3px] right-[-0.8px] bottom-[-0.3px] left-[0.4px] rounded-xl bg-cornflowerblue-200" />
                    <img
                      className="absolute h-full w-full top-[0.3px] right-[-0.8px] bottom-[-0.3px] left-[0.4px] max-w-full overflow-hidden max-h-full z-[1]"
                      alt=""
                      src="/ornament.svg"
                    />
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start gap-[7px_0px]">
                    <div className="relative leading-[24px] font-medium z-[2]">
                      Kenya Sh.
                    </div>
                    <b className="relative text-base tracking-[0.02em] leading-[24px] font-roboto z-[2]">
                      80,435.712
                    </b>
                  </div>
                  <div className="flex flex-col items-start justify-start gap-[10px_0px] text-sm font-roboto">
                    <div className="flex flex-row items-center justify-start py-0 pr-px pl-0 gap-[3px] z-[2]">
                      <img
                        className="h-[16.9px] w-[16.7px] relative"
                        alt=""
                        src="/icon--bitcoin.svg"
                      />
                      <div className="relative tracking-[0.02em] leading-[20px] font-medium">
                        0,0014
                      </div>
                    </div>
                    <input
                      className="m-0 w-[25px] h-[25.4px] relative overflow-hidden shrink-0 z-[2]"
                      type="checkbox"
                    />
                  </div>
                </div>
                <div className="self-stretch flex-1 flex flex-col items-center justify-start py-[13px] px-3 relative">
                  <div className="w-full h-full absolute !m-[0] top-[-0.2px] right-[0.8px] bottom-[0.2px] left-[-0.4px]">
                    <div className="absolute h-full w-full top-[0.3px] right-[-0.7px] bottom-[-0.3px] left-[0.3px] rounded-xl bg-sandybrown" />
                    <img
                      className="absolute h-full w-full top-[0.3px] right-[-0.7px] bottom-[-0.3px] left-[0.3px] max-w-full overflow-hidden max-h-full z-[1]"
                      alt=""
                      src="/ornament-12.svg"
                    />
                  </div>
                  <div className="self-stretch h-[72px] flex flex-col items-start justify-start gap-[16px_0px]">
                    <div className="flex flex-col items-start justify-start gap-[7px_0px]">
                      <div className="relative leading-[24px] font-medium z-[2]">
                        Bitcoin
                      </div>
                      <b className="relative tracking-[0.02em] leading-[24px] font-roboto z-[2]">
                        1.84333767
                      </b>
                    </div>
                    <div className="self-stretch h-0.5 relative box-border z-[2] border-t-[2px] border-dashed border-papayawhip" />
                  </div>
                  <img
                    className="w-[25px] h-[25.4px] absolute !m-[0] bottom-[12.6px] left-[12.4px] overflow-hidden shrink-0 z-[2]"
                    loading="lazy"
                    alt=""
                    src="/icon--credit-card-12.svg"
                  />
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-px pl-0 gap-[0px_13px]">
                <button className="cursor-pointer [border:none] pt-2 pb-[9px] pr-6 pl-[22px] bg-[transparent] flex flex-row items-center justify-center relative">
                  <img
                    className="h-full w-full absolute !m-[0] top-[0.4px] right-[-0.4px] bottom-[-0.4px] left-[0.4px] rounded-xl max-w-full overflow-hidden max-h-full"
                    alt=""
                    src="/bg.svg"
                  />
                  <div className="flex flex-row items-center justify-start gap-[4px] z-[1]">
                    <img
                      className="h-[25.4px] w-[25px] relative overflow-hidden shrink-0"
                      alt=""
                      src="/icon--arrow-up.svg"
                    />
                    <div className="relative text-xs tracking-[0.02em] leading-[16px] font-semibold font-body-m text-seagreen text-left">
                      Withdraw
                    </div>
                  </div>
                </button>
                <button className="cursor-pointer [border:none] pt-2 pb-[9px] pr-[31px] pl-[29px] bg-[transparent] flex flex-row items-center justify-center relative">
                  <img
                    className="h-full w-full absolute !m-[0] top-[0.4px] right-[-0.3px] bottom-[-0.4px] left-[0.3px] rounded-xl max-w-full overflow-hidden max-h-full"
                    alt=""
                    src="/bg-12.svg"
                  />
                  <div className="flex flex-row items-center justify-start gap-[3px] z-[1]">
                    <img
                      className="h-[25.4px] w-[25px] relative overflow-hidden shrink-0"
                      alt=""
                      src="/icon--arrow-up-12.svg"
                    />
                    <div className="relative text-xs tracking-[0.02em] leading-[16px] font-semibold font-body-m text-gray-0 text-left">
                      Deposit
                    </div>
                  </div>
                </button>
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-center justify-start gap-[21px_0px] max-w-full text-smi">
            <div className="w-[333px] h-[241px] flex flex-row items-start justify-start py-0 pr-5 pl-[23px] box-border max-w-full">
              <div className="self-stretch flex-1 flex flex-col items-start justify-start pt-0 pb-px px-0 gap-[21px] z-[1]">
                <div className="self-stretch flex flex-row items-center justify-between gap-[20px] text-lg">
                  <div className="relative leading-[24px] font-medium">
                    Activities
                  </div>
                  <div className="flex flex-row items-center justify-start gap-[6px] text-sm text-lightsteelblue-200">
                    <div className="relative leading-[20px] font-medium">
                      Today
                    </div>
                    <img
                      className="h-[16.9px] w-[16.7px] relative"
                      alt=""
                      src="/icon--chevron.svg"
                    />
                  </div>
                </div>
                <div className="self-stretch flex-1 flex flex-row items-center justify-between py-0 pr-px pl-0 gap-[20px]">
                  <div className="flex flex-row items-center justify-start gap-[0px_12px]">
                    <img
                      className="h-[50.8px] w-[50px] relative"
                      loading="lazy"
                      alt=""
                      src="/logo2.svg"
                    />
                    <div className="flex flex-col items-start justify-start gap-[4px]">
                      <div className="relative tracking-[0.02em] leading-[16px] font-medium">
                        Microsoft
                      </div>
                      <div className="relative text-sm tracking-[0.02em] leading-[16px] text-slategray">
                        Sell
                      </div>
                    </div>
                  </div>
                  <div className="h-[45px] flex flex-col items-end justify-start pt-0 px-0 pb-0 box-border gap-[4px] text-sm text-firebrick font-roboto">
                    <div className="flex flex-row items-center justify-center">
                      <div className="relative tracking-[0.02em] leading-[24px] font-medium">
                        Ksh. 2,435.80
                      </div>
                    </div>
                    <div className="mb-[-1px] w-[82px] flex flex-row items-center justify-start gap-[9px] text-2xs text-health-care-dark-grey-1 font-body-m">
                      <div className="flex-1 relative leading-[18px] font-medium shrink-0">
                        Today
                      </div>
                      <div className="h-[8.5px] w-px relative box-border border-r-[1px] border-solid border-health-care-dark-grey-1" />
                      <div className="flex-1 relative leading-[18px] font-medium shrink-0">
                        16.40
                      </div>
                    </div>
                  </div>
                </div>
                <div className="self-stretch h-[51px] flex flex-row items-center justify-between py-0 pr-px pl-0 box-border gap-[20px]">
                  <div className="w-[98px] flex flex-row items-center justify-start gap-[0px_12px]">
                    <div className="h-[50.8px] flex-1 relative">
                      <div className="absolute h-full w-full top-[-0.98%] right-[-0.8%] bottom-[0.98%] left-[0.8%] rounded-xl bg-royalblue" />
                      <img
                        className="absolute h-[86.61%] w-[91.6%] top-[5.71%] right-[3.6%] bottom-[7.68%] left-[4.8%] rounded-[50%] max-w-full overflow-hidden max-h-full object-cover z-[1]"
                        loading="lazy"
                        alt=""
                        src="/logo-12@2x.png"
                      />
                    </div>
                    <div className="flex flex-col items-start justify-start gap-[5px]">
                      <div className="relative tracking-[0.02em] leading-[16px] font-medium">
                        Tesla
                      </div>
                      <div className="relative text-sm tracking-[0.02em] leading-[16px] text-slategray">
                        Buy
                      </div>
                    </div>
                  </div>
                  <div className="h-[45px] flex flex-col items-end justify-start pt-0 px-0 pb-0 box-border gap-[4px] text-sm text-seagreen font-roboto">
                    <div className="flex flex-row items-center justify-center">
                      <div className="relative tracking-[0.02em] leading-[24px] font-medium">
                        Ksh. 1,435.72
                      </div>
                    </div>
                    <div className="mb-[-1px] w-[82px] flex flex-row items-center justify-start gap-[9px] text-2xs text-health-care-dark-grey-1 font-body-m">
                      <div className="flex-1 relative leading-[18px] font-medium shrink-0">
                        Today
                      </div>
                      <div className="h-[8.5px] w-px relative box-border border-r-[1px] border-solid border-health-care-dark-grey-1" />
                      <div className="flex-1 relative leading-[18px] font-medium shrink-0">
                        14.02
                      </div>
                    </div>
                  </div>
                </div>
                <div className="w-[284px] h-[51px] flex flex-row items-center justify-between py-0 pr-px pl-0 box-border gap-[20px]">
                  <div className="flex flex-row items-center justify-start gap-[0px_12px]">
                    <img
                      className="h-[50.8px] w-[50px] relative"
                      loading="lazy"
                      alt=""
                      src="/logo-22.svg"
                    />
                    <div className="h-[37px] flex flex-col items-start justify-start pt-0 px-0 pb-0 box-border gap-[6px]">
                      <div className="relative tracking-[0.02em] leading-[16px] font-medium">
                        Apple
                      </div>
                      <div className="mb-[-1px] relative text-sm tracking-[0.02em] leading-[16px] text-slategray">
                        Buy
                      </div>
                    </div>
                  </div>
                  <div className="h-[45px] flex flex-col items-center justify-start pt-0 px-0 pb-0 box-border gap-[4px] text-sm text-seagreen font-roboto">
                    <div className="flex flex-row items-center justify-center">
                      <div className="relative tracking-[0.02em] leading-[24px] font-medium">
                        Ksh. 435.24
                      </div>
                    </div>
                    <div className="mt-[-1px] mb-[-1px] flex flex-row items-center justify-start py-0 pr-0.5 pl-px gap-[9px] text-2xs text-health-care-dark-grey-1 font-body-m">
                      <div className="relative leading-[18px] font-medium">
                        Today
                      </div>
                      <div className="h-[8.5px] w-px relative box-border border-r-[1px] border-solid border-health-care-dark-grey-1" />
                      <div className="relative leading-[18px] font-medium">
                        10.12
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="self-stretch h-px relative box-border z-[1] border-t-[1px] border-solid border-aliceblue" />
            <div className="w-[327px] flex flex-col items-start justify-start py-0 px-5 box-border gap-[19px] max-w-full z-[1] text-lg">
              <div className="self-stretch flex flex-row items-center justify-between gap-[20px]">
                <div className="relative leading-[28px] font-medium">News</div>
                <div className="relative text-sm leading-[20px] font-medium text-lightsteelblue-200">
                  See All
                </div>
              </div>
              <div className="self-stretch flex flex-col items-start justify-start gap-[12px_0px] text-xs">
                <div className="self-stretch flex flex-row items-start justify-start gap-[42px]">
                  <div className="flex-1 flex flex-col items-start justify-start gap-[8px_0px]">
                    <div className="w-[183.2px] relative leading-[18px] inline-block">
                      Microsoft, Tesla, Apple News and Price Data
                    </div>
                    <div className="flex flex-row items-center justify-start py-0 px-0 gap-[8px] text-2xs text-lightsteelblue-100">
                      <div className="relative leading-[18px]">News Media</div>
                      <div className="h-[16.9px] w-px relative box-border border-r-[1px] border-solid border-aliceblue" />
                      <div className="relative leading-[18px]">1h ago</div>
                    </div>
                  </div>
                  <img
                    className="h-[63.5px] w-[62.5px] relative min-h-[64px]"
                    loading="lazy"
                    alt=""
                    src="/image2.svg"
                  />
                </div>
                <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-aliceblue" />
                <div className="self-stretch flex flex-row items-start justify-start gap-[42px]">
                  <div className="flex-1 flex flex-col items-start justify-start gap-[8px_0px]">
                    <div className="w-[183.2px] relative leading-[18px] inline-block">
                      Coinbase’s Junk Bonds Show Tesla Really Is Going...
                    </div>
                    <div className="flex flex-row items-center justify-start py-0 px-0 gap-[8px] text-2xs text-lightsteelblue-100">
                      <div className="relative leading-[18px]">News Media</div>
                      <div className="h-[16.9px] w-px relative box-border border-r-[1px] border-solid border-aliceblue" />
                      <div className="relative leading-[18px]">4h ago</div>
                    </div>
                  </div>
                  <img
                    className="h-[63.5px] w-[62.5px] relative min-h-[64px]"
                    loading="lazy"
                    alt=""
                    src="/image2.svg"
                  />
                </div>
                <div className="self-stretch h-px relative box-border border-t-[1px] border-solid border-aliceblue" />
                <div className="self-stretch flex flex-row items-start justify-start gap-[42px]">
                  <div className="flex-1 flex flex-col items-start justify-start gap-[9px_0px]">
                    <div className="w-[183.2px] relative leading-[18px] inline-block">
                      JPMorgan CEO's statement made Tesla price fall...
                    </div>
                    <div className="flex flex-row items-center justify-start py-0 px-0 gap-[8px] text-2xs text-lightsteelblue-100">
                      <div className="relative leading-[18px]">News Media</div>
                      <div className="h-[16.9px] w-px relative box-border border-r-[1px] border-solid border-aliceblue" />
                      <div className="relative leading-[18px]">5h ago</div>
                    </div>
                  </div>
                  <img
                    className="h-[63.5px] w-[62.5px] relative min-h-[64px]"
                    loading="lazy"
                    alt=""
                    src="/image2.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute top-[30px] left-[0px] bg-gray-0 w-full flex flex-row items-center justify-between gap-[20px] max-w-full z-[2] text-cornflowerblue-200 mq450:flex-wrap">
          <div className="relative leading-[32px] font-medium">
            Welcome back!
          </div>
          <div className="flex flex-row items-center justify-start gap-[0px_5px] text-sm">
            <div className="relative leading-[20px]">Harvey Specter</div>
            <img
              className="h-6 w-6 relative rounded-81xl overflow-hidden shrink-0"
              loading="lazy"
              alt=""
              src="/frame-63.svg"
            />
          </div>
        </div>
        <h1 className="m-0 absolute top-[367px] left-[318px] text-17xl leading-[140%] font-medium font-inherit mq450:text-3xl mq450:leading-[30px] mq800:text-10xl mq800:leading-[40px]">
          Deposit
        </h1>
        <div className="absolute top-[551px] left-[177px] w-[420px] flex flex-col items-start justify-start gap-[20px_0px] max-w-full text-xl">
          <div className="self-stretch flex flex-row items-start justify-between py-0 pr-px pl-0 gap-[20px] mq450:flex-wrap">
            <div className="relative leading-[140%] font-medium mq450:text-base mq450:leading-[22px]">
              Account Total :
            </div>
            <div className="relative text-5xl leading-[140%] mq450:text-lgi mq450:leading-[27px]">
              Ksh. 38400
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start gap-[5.55px_0px] max-w-full text-base-6 text-grey-700">
            <div className="flex flex-row items-center justify-start py-0 pr-5 pl-0 gap-[0px_5.55px]">
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                alt=""
                src="/plus.svg"
              />
              <div className="relative leading-[140%] whitespace-pre-wrap">{`Deposit Amount:  `}</div>
            </div>
            <div className="self-stretch h-[58.3px] rounded-[5.55px] box-border overflow-hidden shrink-0 flex flex-row items-center justify-start py-[16.646615982055664px] pr-[13px] pl-[12.484962463378906px] gap-[0px_273.28px] max-w-full border-[1.4px] border-solid border-grey-500">
              <input
                className="w-full [border:none] [outline:none] bg-[transparent] h-[27px] flex-1 flex flex-row items-center justify-start font-body-m text-lgi-4 text-gray1-400 min-w-[237px] max-w-full"
                placeholder="48,000"
                type="text"
              />
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden"
                alt=""
                src="/windowclose.svg"
              />
            </div>
            <div className="w-[86px] h-[22px] hidden flex-row items-center justify-start gap-[0px_5.55px] text-black">
              <img
                className="h-[22.2px] w-[22.2px] relative overflow-hidden shrink-0 hidden min-h-[22px]"
                alt=""
                src="/plus.svg"
              />
              <div className="h-[23px] relative leading-[140%] font-black inline-block whitespace-nowrap shrink-0">
                Helper text
              </div>
            </div>
          </div>
        </div>
        <button
          className="cursor-pointer [border:none] p-[21px] bg-primary-600 absolute top-[731.8px] left-[177px] rounded-4xs w-[420px] overflow-hidden flex flex-row items-center justify-center box-border max-w-full hover:bg-cornflowerblue-100"
          onClick={onDepositFieldClick}
        >
          <div className="relative text-xl leading-[140%] font-extrabold font-body-m text-gray-0 text-left mq450:text-base mq450:leading-[22px]">
            Submit
          </div>
        </button>
        <Dropdown tDX="Deposit" />
      </main>
    </div>
  );
};

export default Deposit;
