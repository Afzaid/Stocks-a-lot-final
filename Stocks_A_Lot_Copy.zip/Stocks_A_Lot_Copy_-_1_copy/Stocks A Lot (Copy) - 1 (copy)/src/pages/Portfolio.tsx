import { FunctionComponent, useCallback } from "react";
import NavBar from "../components/NavBar";
import NetflixMetaAAPL from "../components/NetflixMetaAAPL";
import { useNavigate } from "react-router-dom";

const Portfolio: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBuyAreaClick = useCallback(() => {
    navigate("/buy");
  }, [navigate]);

  const onBuyArea1Click = useCallback(() => {
    navigate("/sell");
  }, [navigate]);

  return (
    <div className="w-full relative bg-gray-0 overflow-hidden flex flex-row items-start justify-start gap-[0px_45px] tracking-[normal] mq800:gap-[0px_45px] mq1300:flex-wrap">
      <NavBar />
      <main className="w-[1093px] flex flex-col items-start justify-start pt-[30px] px-0 pb-0 box-border max-w-full">
        <section className="self-stretch flex flex-col items-start justify-start gap-[88px_0px] max-w-full text-left text-lg text-cornflowerblue-200 font-body-m mq800:gap-[88px_0px] mq1125:gap-[88px_0px]">
          <div className="self-stretch flex flex-row items-start justify-start py-0 pr-0 pl-[17px] box-border max-w-full">
            <div className="flex-1 bg-gray-0 flex flex-row items-center justify-between max-w-full gap-[20px] mq450:flex-wrap">
              <h3 className="m-0 relative text-inherit leading-[32px] font-medium font-inherit">
                Welcome back!
              </h3>
              <div className="flex flex-row items-center justify-start gap-[0px_5px] text-sm">
                <div className="relative leading-[20px]">Harvey Specter</div>
                <img
                  className="h-6 w-6 relative rounded-81xl overflow-hidden shrink-0"
                  loading="lazy"
                  alt=""
                  src="/frame-63.svg"
                />
              </div>
            </div>
          </div>
          <div className="self-stretch flex flex-col items-start justify-start py-0 pr-[21px] pl-0 box-border gap-[38px_0px] max-w-full text-5xl font-body-text-2-bold mq800:gap-[38px_0px]">
            <div className="self-stretch flex flex-col items-start justify-start py-0 px-0 box-border relative gap-[52px_0px] max-w-full mq800:gap-[52px_0px]">
              <div className="w-[321px] !m-[0] absolute top-[90px] left-[28px] bg-yellow [filter:blur(50px)] h-[168px] overflow-hidden shrink-0 hidden z-[0]" />
              <div className="w-[321px] !m-[0] absolute top-[90px] left-[396px] bg-yellow [filter:blur(50px)] h-[168px] overflow-hidden shrink-0 hidden z-[1]" />
              <div className="w-[321px] !m-[0] absolute top-[88px] left-[773px] bg-yellow [filter:blur(50px)] h-[168px] overflow-hidden shrink-0 hidden z-[2]" />
              <div className="self-stretch flex flex-col items-start justify-start gap-[32px_0px] max-w-full mq800:gap-[32px_0px]">
                <div className="self-stretch flex flex-row items-center justify-between gap-[20px] mq450:flex-wrap">
                  <h1 className="m-0 relative text-inherit leading-[32px] font-medium font-inherit mq450:text-lgi mq450:leading-[26px]">
                    Your Stock Portfolio
                  </h1>
                  <button className="cursor-pointer [border:none] p-0 bg-[transparent] flex flex-row items-center justify-start gap-[0px_5px]">
                    <div className="relative text-sm leading-[20px] font-medium font-body-text-2-bold text-cornflowerblue-200 text-left">
                      View All
                    </div>
                    <img
                      className="h-[9.6px] w-2.5 relative"
                      alt=""
                      src="/-icon-arrow-right.svg"
                    />
                  </button>
                </div>
                <div className="self-stretch grid flex-row items-start justify-start gap-[0px_28px] max-w-full grid-cols-[repeat(3,_minmax(255px,_1fr))] mq800:grid-cols-[minmax(255px,_1fr)] mq1125:justify-center mq1125:grid-cols-[repeat(2,_minmax(255px,_442px))]">
                  <NetflixMetaAAPL
                    netflix="Netflix"
                    ksh41603="Ksh. 416.03"
                    nFLX="NFLX"
                    ellipseDot="+2.37%"
                    janFebMarApr="/vector-7.svg"
                  />
                  <NetflixMetaAAPL
                    netflix="Meta"
                    ksh41603="Ksh. 285.50"
                    nFLX="META"
                    ellipseDot="-0.44%"
                    janFebMarApr="/vector-16.svg"
                    propColor="#ba2d0b"
                    propTransform=" rotate(180deg)"
                    propTransform1=" rotate(-180deg)"
                    propTransform2=" rotate(-180deg)"
                    propTransform3=" rotate(-180deg)"
                    propTransform4=" rotate(-180deg)"
                    propTransform5=" rotate(-180deg)"
                    propTransform6=" rotate(-180deg)"
                    propTransform7=" rotate(-180deg)"
                    propTransform8=" rotate(-180deg)"
                    propTransform9=" rotate(-180deg)"
                  />
                  <NetflixMetaAAPL
                    netflix="Apple"
                    ksh41603="Ksh. 178.61"
                    nFLX="AAPL"
                    ellipseDot="+1.36%"
                    janFebMarApr="/vector-25.svg"
                    propColor="#007f5f"
                    propTransform="unset"
                    propTransform1="unset"
                    propTransform2="unset"
                    propTransform3="unset"
                    propTransform4="unset"
                    propTransform5="unset"
                    propTransform6="unset"
                    propTransform7="unset"
                    propTransform8="unset"
                    propTransform9="unset"
                  />
                </div>
              </div>
              <div className="self-stretch flex flex-row items-start justify-start gap-[0px_28px] max-w-full text-base text-darkgray mq1125:flex-wrap">
                <div className="flex-1 rounded-4xs bg-gray-0 box-border flex flex-col items-center justify-start py-4 pr-[19px] pl-[21px] relative gap-[40px_0px] min-w-[460px] max-w-full border-[1px] border-solid border-whitesmoke-300 mq800:gap-[40px_0px] mq800:min-w-full">
                  <div className="self-stretch flex flex-row items-start justify-between py-0 px-[3px] gap-[20px] mq450:flex-wrap">
                    <div className="w-[166px] flex flex-col items-start justify-center gap-[8px_0px]">
                      <div className="relative leading-[32px] font-medium">
                        Total Value
                      </div>
                      <b className="self-stretch relative text-5xl leading-[28px] text-cornflowerblue-200 mq450:text-lgi mq450:leading-[22px]">
                        Ksh. 10,216.53
                      </b>
                    </div>
                    <div className="w-48 flex flex-row items-start justify-start gap-[0px_8px]">
                      <button className="cursor-pointer [border:none] py-1 px-3 bg-gray-0 flex flex-col items-center justify-center hover:bg-gainsboro-100">
                        <div className="relative text-sm leading-[20px] font-body-text-2-bold text-gray1-100 text-left">
                          Day
                        </div>
                      </button>
                      <button className="cursor-pointer [border:none] py-1 px-2.5 bg-gray-0 flex-1 flex flex-col items-center justify-center whitespace-nowrap hover:bg-gainsboro-100">
                        <div className="relative text-sm leading-[20px] font-body-text-2-bold text-gray1-100 text-left">{`Week `}</div>
                      </button>
                      <button className="cursor-pointer [border:none] py-1 px-3 bg-cornflowerblue-200 flex-1 flex flex-col items-center justify-center hover:bg-deepskyblue">
                        <div className="relative text-sm leading-[20px] font-medium font-body-text-2-bold text-gray-0 text-left">
                          Month
                        </div>
                      </button>
                    </div>
                  </div>
                  <div className="self-stretch flex flex-col items-center justify-center max-w-full text-mini-5 text-gray-0 font-body-m">
                    <div className="self-stretch flex flex-row items-center justify-center relative max-w-full">
                      <div className="flex-1 flex flex-col items-end justify-start gap-[17px] max-w-full">
                        <div className="self-stretch flex flex-row items-start justify-start py-0 pr-[3px] pl-0.5 box-border max-w-full">
                          <div className="flex-1 flex flex-col items-start justify-start relative gap-[54.18px_0px] max-w-full mq800:gap-[54.18px_0px]">
                            <img
                              className="self-stretch relative max-w-full overflow-hidden max-h-full"
                              alt=""
                              src="/vector-27.svg"
                            />
                            <img
                              className="self-stretch relative max-w-full overflow-hidden max-h-full"
                              alt=""
                              src="/vector-28.svg"
                            />
                            <img
                              className="self-stretch relative max-w-full overflow-hidden max-h-full"
                              alt=""
                              src="/vector-29.svg"
                            />
                            <img
                              className="self-stretch relative max-w-full overflow-hidden max-h-full"
                              alt=""
                              src="/vector-30.svg"
                            />
                            <img
                              className="self-stretch relative max-w-full overflow-hidden max-h-full"
                              alt=""
                              src="/vector-31.svg"
                            />
                            <img
                              className="w-0 h-[105px] absolute !m-[0] top-[112px] left-[411.4px] object-contain z-[1]"
                              alt=""
                              src="/vector-32.svg"
                            />
                            <div className="w-2 h-2 absolute !m-[0] top-[107px] left-[407.4px] rounded-[50%] bg-cornflowerblue-200 z-[2]" />
                            <img
                              className="w-[660.1px] h-[169.5px] absolute !m-[0] right-[-2.5px] bottom-[0.2px] mix-blend-screen z-[3]"
                              alt=""
                              src="/vector-33.svg"
                            />
                            <img
                              className="w-[658.9px] h-[103.6px] absolute !m-[0] top-[47px] right-[-1.3px] z-[4]"
                              alt=""
                              src="/vector-34.svg"
                            />
                          </div>
                        </div>
                        <div className="self-stretch flex flex-row items-start justify-between py-0 pr-[11px] pl-0 gap-[20px] mq800:flex-wrap">
                          <div className="relative font-black">Jan</div>
                          <div className="relative font-black">Feb</div>
                          <div className="h-[16.9px] w-[31px] relative font-black inline-block shrink-0">
                            Mar
                          </div>
                          <div className="relative font-black">Apr</div>
                          <div className="h-[16.9px] w-[34px] relative font-black inline-block shrink-0">
                            May
                          </div>
                          <div className="relative font-black">Jun</div>
                          <div className="w-[28.9px] relative font-black inline-block shrink-0">
                            Jul
                          </div>
                          <div className="h-[16.9px] w-8 relative font-black inline-block shrink-0">
                            Aug
                          </div>
                          <div className="relative font-black">Sep</div>
                          <div className="relative font-black">Oct</div>
                          <div className="h-[16.9px] w-[31px] relative font-black inline-block shrink-0">
                            Nov
                          </div>
                          <div className="relative font-black">Dec</div>
                        </div>
                        <div className="w-[361.7px] overflow-x-auto hidden flex-row items-start justify-between max-w-full gap-[20px]">
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-35.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-36.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-37.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-38.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-39.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-40.svg"
                          />
                          <img
                            className="self-stretch w-0 relative max-h-full shrink-0 min-h-[279px]"
                            alt=""
                            src="/vector-41.svg"
                          />
                        </div>
                      </div>
                      <div className="!m-[0] absolute top-[37px] right-[218.4px] bg-gray1-200 shadow-[2px_2px_20px_rgba(0,_0,_0,_0.25)] flex flex-col items-center justify-start py-2 pr-3 pl-4 z-[1] text-xs text-darkgray font-body-text-2-bold">
                        <div className="flex flex-row items-start justify-start py-0 pr-[23px] pl-5">
                          <div className="relative leading-[20px]">Aug 12</div>
                        </div>
                        <b className="relative text-base leading-[20px] text-gray-0">
                          Ksh. 9,239.12
                        </b>
                      </div>
                    </div>
                  </div>
                  <div className="w-1 h-[390px] absolute !m-[0] top-[0px] left-[0px] bg-gray1-300 hidden z-[2]" />
                </div>
                <div className="w-[340px] rounded-4xs bg-gray-0 box-border flex flex-col items-start justify-start py-4 pr-[25px] pl-[23px] relative gap-[32px_0px] min-w-[340px] max-w-full text-xl text-gray-0 border-[1px] border-solid border-whitesmoke-300 mq450:gap-[32px_0px] mq450:min-w-full mq1125:flex-1">
                  <div className="self-stretch flex flex-row items-baseline justify-between gap-[20px]">
                    <h2 className="m-0 relative text-inherit leading-[32px] font-medium font-inherit mq450:text-base mq450:leading-[26px]">
                      Stock Chart
                    </h2>
                    <div className="flex flex-row items-center justify-start gap-[0px_8px] text-sm text-cornflowerblue-200">
                      <div className="relative leading-[20px] font-medium">
                        View All
                      </div>
                      <img
                        className="h-[9.6px] w-2.5 relative"
                        alt=""
                        src="/-icon-arrow-right.svg"
                      />
                    </div>
                  </div>
                  <div className="self-stretch flex flex-col items-start justify-start gap-[12px_0px] text-xs text-black">
                    <div className="self-stretch bg-gray-0 flex flex-row items-start justify-between py-1 px-2 gap-[20px] text-darkgray">
                      <b className="relative leading-[20px]">#</b>
                      <b className="w-12 relative leading-[20px] flex items-center shrink-0">
                        Name
                      </b>
                      <b className="w-12 relative leading-[20px] flex items-center shrink-0">
                        Price
                      </b>
                      <b className="w-[52px] relative leading-[20px] flex items-center shrink-0">
                        Status
                      </b>
                    </div>
                    <div className="self-stretch flex flex-row items-center justify-between py-1 px-2 gap-[20px]">
                      <div className="w-3.5 relative leading-[32px] font-medium text-center flex items-center justify-center shrink-0">
                        1
                      </div>
                      <div className="w-12 relative leading-[32px] font-medium flex items-center shrink-0">
                        NFLX
                      </div>
                      <div className="relative leading-[32px] font-medium">
                        Ksh. 416.03
                      </div>
                      <div className="w-12 relative leading-[20px] text-seagreen flex items-center shrink-0">
                        +2.37%
                      </div>
                    </div>
                    <div className="self-stretch flex flex-row items-center justify-between py-1 px-2 gap-[20px]">
                      <div className="w-3.5 relative leading-[32px] font-medium text-center flex items-center justify-center shrink-0">
                        2
                      </div>
                      <div className="w-12 relative leading-[32px] font-medium flex items-center shrink-0">
                        AMZN
                      </div>
                      <div className="relative leading-[32px] font-medium">
                        Ksh. 251.64
                      </div>
                      <div className="w-12 relative leading-[20px] text-seagreen flex items-center shrink-0">
                        +2.09%
                      </div>
                    </div>
                    <div className="self-stretch flex flex-row items-center justify-between py-1 px-2 gap-[20px]">
                      <div className="w-3.5 relative leading-[32px] font-medium text-center flex items-center justify-center shrink-0">
                        3
                      </div>
                      <div className="w-12 relative leading-[32px] font-medium flex items-center shrink-0">
                        AAPL
                      </div>
                      <div className="relative leading-[32px] font-medium">
                        Ksh. 178.61
                      </div>
                      <div className="w-12 relative leading-[20px] text-seagreen flex items-center shrink-0">
                        +1.36%
                      </div>
                    </div>
                    <div className="self-stretch flex flex-row items-center justify-between py-1 px-2 gap-[20px]">
                      <div className="w-3.5 relative leading-[32px] font-medium text-center flex items-center justify-center shrink-0">
                        4
                      </div>
                      <div className="w-12 relative leading-[32px] font-medium flex items-center shrink-0">
                        NFLX
                      </div>
                      <div className="relative leading-[32px] font-medium">
                        Ksh. 416.03
                      </div>
                      <div className="w-12 relative leading-[20px] text-seagreen flex items-center shrink-0">
                        +0.25%
                      </div>
                    </div>
                    <div className="self-stretch flex flex-row items-center justify-between py-1 px-2 gap-[20px]">
                      <div className="w-3.5 relative leading-[32px] font-medium text-center flex items-center justify-center shrink-0">
                        5
                      </div>
                      <div className="w-12 relative leading-[32px] font-medium flex items-center shrink-0">
                        META
                      </div>
                      <div className="relative leading-[32px] font-medium">
                        Ksh. 285.50
                      </div>
                      <div className="w-12 relative leading-[20px] text-firebrick flex items-center shrink-0">
                        -0.44%
                      </div>
                    </div>
                  </div>
                  <div className="w-1 h-[390px] absolute !m-[0] top-[0px] left-[0px] bg-gray1-300 hidden z-[2]" />
                </div>
              </div>
            </div>
            <div className="w-[756px] flex flex-row items-start justify-center py-0 px-5 box-border max-w-full">
              <div className="w-[562px] flex flex-row items-start justify-start gap-[0px_30px] max-w-full mq800:flex-wrap">
                <button
                  className="cursor-pointer [border:none] py-[21px] pr-[21px] pl-5 bg-primary-600 flex-1 rounded-4xs overflow-hidden flex flex-row items-center justify-center box-border min-w-[173px] hover:bg-cornflowerblue-100"
                  onClick={onBuyAreaClick}
                >
                  <div className="relative text-xl leading-[140%] font-extrabold font-body-m text-gray-0 text-left mq450:text-base mq450:leading-[22px]">
                    Buy
                  </div>
                </button>
                <button
                  className="cursor-pointer [border:none] p-[21px] bg-primary-600 flex-1 rounded-4xs overflow-hidden flex flex-row items-center justify-center box-border min-w-[173px] hover:bg-cornflowerblue-100"
                  onClick={onBuyArea1Click}
                >
                  <div className="relative text-xl leading-[140%] font-extrabold font-body-m text-gray-0 text-left mq450:text-base mq450:leading-[22px]">
                    Sell
                  </div>
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Portfolio;
