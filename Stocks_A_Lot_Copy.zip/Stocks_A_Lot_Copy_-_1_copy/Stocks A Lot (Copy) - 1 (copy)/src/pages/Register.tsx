import { FunctionComponent, useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Form from "react-bootstrap/Form";

import Button from "react-bootstrap/Button";

const Register: FunctionComponent = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    username: "",
    phoneNumber: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:3001/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      });
      if (response.ok) {
        toast.success("User registered successfully!");
        navigate("/account-setup");
      } else {
        const data = await response.json();
        toast.error(data.message);
      }
    } catch (error) {
      console.error('Error registering user:', error);
      toast.error("An error occurred. Please try again.");
    }
  };

  const onAlreadyHaveAnClick = useCallback(() => {
    navigate("/sign-in");
  }, [navigate]);

  return (
    <div>
      <ToastContainer />
      <div className="w-full relative bg-whitesmoke-100 overflow-hidden flex flex-row items-center justify-center pt-[211px] pb-[210px] pr-[21px] pl-5 box-border tracking-[normal] text-left text-13xl text-primary-800 font-heading-6">
        <div className="w-[719px] rounded-xl bg-gray-0 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] overflow-hidden shrink-0 flex flex-row items-end justify-start pt-10 pb-8 pr-[39px] pl-[50px] box-border gap-[0px_27px] max-w-full mq675:flex-wrap mq675:pt-[26px] mq675:pb-[21px] mq675:box-border mq750:pl-[25px] mq750:box-border">
          <div className="flex-1 flex flex-col items-start justify-start pt-0 px-0 pb-[11px] box-border min-w-[206px]">
            <div className="self-stretch flex flex-col items-center justify-start gap-[228px_0px] mq450:gap-[228px_0px]">
              <div className="self-stretch flex flex-row items-center justify-start gap-[0px_29px] mq450:flex-wrap">
                <img
                  className="h-[90px] w-[86.1px] relative"
                  loading="lazy"
                  alt=""
                  src="/group-39796.svg"
                />
                <div className="flex-1 flex flex-col items-start justify-start pt-0.5 px-0 pb-0 box-border min-w-[131px]">
                  <h1 className="m-0 relative text-inherit leading-[64px] font-bold font-inherit mq450:text-lgi mq450:leading-[38px] mq750:text-7xl mq750:leading-[51px]">
                    Stocks A Lot
                  </h1>
                </div>
              </div>
              <div className="flex flex-row items-start justify-start py-0 pr-[11px] pl-0 text-sm text-black font-body-m">
                <div
                  className="relative [text-decoration:underline] leading-[140%] font-extralight cursor-pointer"
                  onClick={onAlreadyHaveAnClick}
                >
                  Already have an account?
                </div>
              </div>
            </div>
          </div>
          <Form className="m-0 w-[286px] flex flex-col items-center justify-start gap-[21px_0px] min-w-[286px] mq675:flex-1" onSubmit={handleSubmit}>
            <div className="self-stretch flex flex-col items-center justify-center py-5 px-2.5 gap-[10px_0px]">
              <Form.Control type="text" placeholder="Full Name*" name="fullName" value={formData.fullName} onChange={handleChange} />
              <Form.Control type="text" placeholder="Username*" name="username" value={formData.username} onChange={handleChange} />
              <Form.Control type="tel" placeholder="Phone Number*" name="phoneNumber" value={formData.phoneNumber} onChange={handleChange} />
              <Form.Control type="email" placeholder="Email*" name="email" value={formData.email} onChange={handleChange} />
              <Form.Control type="password" placeholder="Password*" name="password" value={formData.password} onChange={handleChange} />
              <Form.Control type="password" placeholder="Confirm Password*" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange} />
            </div>
            <Button type="submit" className="bg-primary-600 hover:bg-cornflowerblue-100 text-gray-0 py-2 px-4 rounded">
              Continue
            </Button>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default Register;
