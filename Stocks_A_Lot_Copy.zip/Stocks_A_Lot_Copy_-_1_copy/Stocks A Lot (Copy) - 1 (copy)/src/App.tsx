import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Home from "./pages/Home";
import Portfolio from "./pages/Portfolio";
import Payment from "./pages/Payment";
import AdminPage from "./pages/AdminPage";
import Deposit from "./pages/Deposit";
import Withdrawal from "./pages/Withdrawal";
import Sell from "./pages/Sell";
import Buy from "./pages/Buy";
import TransactionHistory from "./pages/TransactionHistory";
import Register from "./pages/Register";
import SignIn from "./pages/SignIn";
import AccountSetup from "./pages/AccountSetup";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/portfolio":
        title = "";
        metaDescription = "";
        break;
      case "/payment":
        title = "";
        metaDescription = "";
        break;
      case "/admin-page-1":
        title = "";
        metaDescription = "";
        break;
      case "/deposit":
        title = "";
        metaDescription = "";
        break;
      case "/withdrawal":
        title = "";
        metaDescription = "";
        break;
      case "/sell":
        title = "";
        metaDescription = "";
        break;
      case "/buy":
        title = "";
        metaDescription = "";
        break;
      case "/transaction-history":
        title = "";
        metaDescription = "";
        break;
      case "/register":
        title = "";
        metaDescription = "";
        break;
      case "/sign-in":
        title = "";
        metaDescription = "";
        break;
      case "/account-setup":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/portfolio" element={<Portfolio />} />
      <Route path="/payment" element={<Payment />} />
      <Route path="/admin-page-1" element={<AdminPage />} />
      <Route path="/deposit" element={<Deposit />} />
      <Route path="/withdrawal" element={<Withdrawal />} />
      <Route path="/sell" element={<Sell />} />
      <Route path="/buy" element={<Buy />} />
      <Route path="/transaction-history" element={<TransactionHistory />} />
      <Route path="/register" element={<Register />} />
      <Route path="/sign-in" element={<SignIn />} />
      <Route path="/account-setup" element={<AccountSetup />} />
    </Routes>
  );
}
export default App;
