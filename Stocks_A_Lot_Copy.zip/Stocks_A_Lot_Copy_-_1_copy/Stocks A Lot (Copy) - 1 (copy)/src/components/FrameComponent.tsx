import React, { useState, useCallback, FunctionComponent, FormEvent } from "react";
import Logo from "./Logo";
import { useNavigate } from "react-router-dom";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';



const FrameComponent: FunctionComponent = () => {
  const navigate = useNavigate();
  const [email, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const onDontHaveAnClick = useCallback(() => {
    navigate("/register");
  }, [navigate]);

  const onFrameButtonClick = useCallback(async (e: FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:3001/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
  
      const data = await response.json();
      if (response.ok) {
        toast.success('Login successful');
        navigate("/portfolio");
      } else {
        throw new Error(data.message || "Failed to log in");
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please try again.');
    }
  }, [email, password, navigate]);
  

  return (
    <Form 
      className="m-0 h-[342px] w-[752.1px] rounded-xl bg-gray-0 shadow-[0px_4px_4px_rgba(0,_0,_0,_0.25)] overflow-hidden shrink-0 flex flex-row flex-wrap items-center justify-center py-[27px] px-10 box-border relative gap-[70px_91px] max-w-full mq450:h-auto mq450:min-h-[342]"
      onSubmit={onFrameButtonClick}
    >
      <Logo />
      <div className="w-[286px] !m-[0] absolute top-[27px] left-[424.1px] flex flex-col items-center justify-center py-5 px-2.5 box-border gap-[10px_0px]">
        <Form.Group controlId="formBasicUsername">
          <Form.Control type="text" placeholder="Username" value={email} onChange={(e) => setUsername(e.target.value)} />
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
          <Form.Control type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </Form.Group>
      </div>
      <div
        className="absolute !m-[0] top-[284px] left-[115.1px] text-sm [text-decoration:underline] leading-[140%] font-extralight font-body-m text-black text-left cursor-pointer"
        onClick={onDontHaveAnClick}
      >
        Don’t have an account?
      </div>
      <Button
        className="cursor-pointer [border:none] py-[11px] pr-[123px] pl-[103px] bg-primary-600 !m-[0] absolute top-[273px] left-[371.1px] rounded-4xs overflow-hidden flex flex-row items-center justify-start hover:bg-cornflowerblue-100"
        type="submit"
      >
        <div className="relative text-sm leading-[140%] font-extrabold font-body-m text-gray-0 text-left">
          Login
        </div>
      </Button>
      <ToastContainer/>
    </Form>
  );
};

export default FrameComponent;
